package com.kylingo.annotation.support;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * SOURCE：表示在编译时这个注解会被移除，不会包含在编译后产生的class文件中。
 * CLASS：表示这个注解会被包含在class文件中，但在运行时会被移除。
 * RUNTIME：表示这个注解会被保留到运行时，我们可以在运行时通过反射解析这个注解。
 *
 * @author kylingo on 18/6/26
 */
@Retention(RetentionPolicy.CLASS)
public @interface RetentionInfo {

}
