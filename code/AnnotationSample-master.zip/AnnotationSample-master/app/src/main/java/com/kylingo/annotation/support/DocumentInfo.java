package com.kylingo.annotation.support;

import java.lang.annotation.Documented;

/**
 * 当一个注解类型被@Documented元注解所描述时，那么无论在哪里使用这个注解，都会被Javadoc工具文档化
 *
 * @author kylingo on 18/6/26
 */
@Documented
public @interface DocumentInfo {
}
