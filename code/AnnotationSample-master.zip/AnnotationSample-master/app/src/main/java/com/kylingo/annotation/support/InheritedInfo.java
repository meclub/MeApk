package com.kylingo.annotation.support;

import java.lang.annotation.Inherited;

/**
 * 表明被修饰的注解类型是自动继承的，若一个注解被Inherited元注解修饰，则当用户在一个类声明中查询该注解类型时，
 * 若发现这个类声明不包含这个注解类型，则会自动在这个类的父类中查询相应的注解类型。
 *
 * @author kylingo on 18/6/26
 */
@Inherited
public @interface InheritedInfo {
}
