package com.kylingo.annotation.support;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 元注解，描述注解使用范围
 * ElementType是一个枚举类型，它包括：
 * <p>
 * TYPE：类、接口、注解类型或枚举类型。
 * PACKAGE：注解包。
 * PARAMETER：注解参数。
 * ANNOTATION_TYPE：注解 注解类型。
 * METHOD：方法。
 * FIELD：属性（包括枚举常量）
 * CONSTRUCTOR：构造器。
 * LOCAL_VARIABLE：局部变量。
 * <p>
 *
 * @author kylingo on 18/6/26
 */
@Target(ElementType.METHOD)
public @interface MethodInfo {

    /**
     * 注解类型是用@interface关键字定义的。
     * 所有的方法均没有方法体，且只允许public和abstract这两种修饰符号，默认为public。
     * 注解方法只能返回：原始数据类型，String，Class，枚举类型，注解，它们的一维数组。
     */
    String author() default "kylingo";

    String value() default "";

    int version() default 1;
}
