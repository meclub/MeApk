package com.kylingo.annotation;

import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.Name;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.TypeMirror;

/**
 * @author kylingo on 18/6/26
 */
public class BindViewField {

    private VariableElement mFieldElement;
    private int mResId;
    private String mInitValue;

    public BindViewField(Element element) throws IllegalArgumentException {
        if (element.getKind() != ElementKind.FIELD) { //判断被注解修饰的是否是变量.
            throw new IllegalArgumentException(String.format("Only fields can be annotated with @%s", BindView.class.getSimpleName()));
        }
        mFieldElement = (VariableElement) element; //获得被修饰变量.
        BindView bindView = mFieldElement.getAnnotation(BindView.class); //获得被修饰变量的注解.
        mResId = bindView.value(); //获得注解的值.
    }

    /**
     * @return 被修饰变量的名字.
     */
    public Name getFieldName() {
        return mFieldElement.getSimpleName();
    }

    /**
     * @return 被修饰变量的注解的值, 也就是它的id.
     */
    public int getResId() {
        return mResId;
    }

    /**
     * @return 被修饰变量的注解的值.
     */
    public String getInitValue() {
        return mInitValue;
    }

    /**
     * @return 被修饰变量的类型.
     */
    public TypeMirror getFieldType() {
        return mFieldElement.asType();
    }
}
