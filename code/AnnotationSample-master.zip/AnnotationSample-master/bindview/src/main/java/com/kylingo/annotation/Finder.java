package com.kylingo.annotation;

import com.kylingo.annotation.provider.Provider;

/**
 * @author kylingo on 18/6/26
 */
public interface Finder<T> {

    /**
     * @param host     持有注解的类
     * @param source   调用方法的所在的类
     * @param provider 执行方法的类
     */
    void inject(T host, Object source, Provider provider);
}
