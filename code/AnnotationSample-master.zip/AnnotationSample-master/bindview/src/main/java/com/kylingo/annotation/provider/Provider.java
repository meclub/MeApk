package com.kylingo.annotation.provider;

import android.content.Context;
import android.view.View;

/**
 * @author kylingo on 18/6/26
 */
public interface Provider {

    Context getContext(Object source);

    View findView(Object source, int resId);
}
