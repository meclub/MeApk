package com.kylingo.annotation.provider;

import android.content.Context;
import android.view.View;

/**
 * @author kylingo on 18/6/26
 */
public class ViewProvider implements Provider {

    @Override
    public Context getContext(Object source) {
        return ((View) source).getContext();
    }

    @Override
    public View findView(Object source, int resId) {
        return ((View) source).findViewById(resId);
    }
}
