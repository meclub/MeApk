package com.ucpaas.chat.bean;

/**
 *
 * @author tangqi
 * @date 2015年9月7日上午4:08:44
 */

public class ResultInfo {
	private String result;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
}
