package com.ucpaas.chat.support;

import com.yzxIM.data.CategoryId;
import com.yzxIM.data.db.ConversationInfo;

/**
 * UC聊天相关工具
 * 
 * @author tangqi
 * @date 2015年9月3日下午9:11:45
 */

public class UcUtils {

}
