package com.ucpaas.chat.listener;

/**
 * 取消监听器
 * 
 * @author Administrator
 *
 */
public interface CancleListener {

	/**
	 * 取消
	 * 
	 * @param result
	 */
	public void cancle(String result);
}
