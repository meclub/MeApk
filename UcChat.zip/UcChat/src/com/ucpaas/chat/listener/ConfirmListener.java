package com.ucpaas.chat.listener;

/**
 * 确认监听器
 * 
 * @author Administrator
 *
 */
public interface ConfirmListener {

	/**
	 * 确认
	 * 
	 * @param result
	 */
	public void confirm(String result);
}
