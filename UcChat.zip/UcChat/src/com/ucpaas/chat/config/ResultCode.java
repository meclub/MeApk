/** Copyright © 2015-2020 100msh.com All Rights Reserved */
package com.ucpaas.chat.config;

/**
 * 请求结果返回码
 * 
 * @author Frank
 * @date 2015年9月2日上午11:04:50
 */

public class ResultCode {
	
	public final static String OK = "0";
	public final static int TITLE = 1;
}
